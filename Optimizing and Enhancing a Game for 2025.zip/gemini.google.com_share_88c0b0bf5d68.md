# ‎Gemini -

**URL:** https://gemini.google.com/share/88c0b0bf5d68

---

Sign in
Gemini
About Gemini
Opens in a new window
Gemini App
Opens in a new window
Subscriptions
Opens in a new window
For Business
Opens in a new window
This content was created by another person. It may be inaccurate or unsafe. Report unsafe content
Opens in a new window
Code
Preview
Try Gemini Canvas
You need to sign in with your Google Account to see some features
 This app was created by another person

It may be unsafe. Be cautious and only continue with apps you trust. Report unsafe content
Opens in a new window

Keep your personal info private
Don't share things like passwords or payment details. Anyone with this public link could access and edit shared data.
Try Gemini
Continue
You need to sign in with your Google Account to see some features
Sign in