import React from 'react';
import { useGame } from '@/contexts/GameContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, RotateCcw, Send, Clock, Trophy, Flame } from 'lucide-react';
import { LETTER_STYLES } from '@/lib/gameData';
import PowerUpsPanel from './PowerUpsPanel';
import WordDefinition from './WordDefinition';

export default function GameScreen() {
  const { state, selectLetter, clearGuess, submitWord, endGame } = useGame();

  // Keyboard shortcuts
  React.useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (state.currentGuess.length >= 2) {
          submitWord();
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        clearGuess();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        if (state.currentGuess.length > 0) {
          clearGuess();
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [state.currentGuess, submitWord, clearGuess]);

  const currentWord = state.currentGuess.map(g => g[0]).join('');
  const usedIndices = new Set(state.currentGuess.map(g => parseInt(g.slice(1))));
  
  const equippedStyle = LETTER_STYLES.find(s => s.id === state.equippedStyle);
  const styleClass = equippedStyle?.className || LETTER_STYLES[0].className;

  const comboMultiplier = 1 + (state.combo * 0.2);
  const comboColor = state.combo >= 5 ? 'text-accent' : state.combo >= 3 ? 'text-secondary' : 'text-primary';

  // Get active power-up name
  const getActivePowerUpName = () => {
    switch (state.activePowerUp) {
      case 'timeFreeze': return '❄️ Time Freeze Active!';
      case 'letterShuffle': return '🔀 Letters Shuffled!';
      case 'doublePoints': return '⭐ Double Points Active!';
      case 'hintBomb': return '💡 Hint Revealed!';
      case 'letterMagnet': return '🧲 Word Auto-Completed!';
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col p-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-card to-background opacity-50" />
      
      <div className="relative z-10 w-full max-w-4xl mx-auto space-y-6">
        {/* Surge Mode Banner */}
        {state.surgeMode && (
          <div className="animate-pulse-scale">
            <Card className="glass-strong p-6 bg-gradient-to-r from-orange-200 via-pink-200 to-purple-200 border-4 border-yellow-400 glow-orange shadow-2xl">
              <div className="flex items-center justify-center gap-3">
                <Flame className="w-8 h-8 text-orange-600 animate-bounce" />
                <p className="text-center text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-pink-600">
                  🔥 SURGE MODE! 🔥
                </p>
                <Flame className="w-8 h-8 text-orange-600 animate-bounce" />
              </div>
              <p className="text-center text-sm font-bold text-purple-700 mt-2">
                {state.surgeMultiplier}x Score Multiplier!
              </p>
            </Card>
          </div>
        )}
        
        {/* Active Power-Up Banner */}
        {state.activePowerUp && (
          <div className="animate-bounce-in">
            <Card className="glass-strong p-4 bg-gradient-to-r from-yellow-100 to-orange-100 border-2 border-yellow-400 glow-orange">
              <p className="text-center text-lg font-bold text-yellow-900">
                {getActivePowerUpName()}
              </p>
            </Card>
          </div>
        )}
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={endGame}
            className="glass"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Quit
          </Button>
          
          <div className="flex items-center gap-4">
            {state.gameMode !== 'zen' && state.gameMode !== 'daily' && (
              <Card className="glass px-4 py-2 flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                <span className="text-2xl font-bold text-primary">
                  {state.timeRemaining}s
                </span>
              </Card>
            )}
            
            <Card className="glass px-4 py-2 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-accent" />
              <span className="text-2xl font-bold text-accent">
                {state.score}
              </span>
            </Card>
          </div>
        </div>

        {/* Combo Meter */}
        {state.combo > 0 && (
          <Card className={`glass p-4 animate-bounce-in ${state.combo >= 5 ? 'box-glow-strong animate-pulse-glow' : ''}`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Flame className={`w-6 h-6 ${comboColor}`} />
                <span className={`text-2xl font-bold ${comboColor} text-glow`}>
                  {state.combo}x COMBO
                </span>
              </div>
              <span className="text-lg text-muted-foreground">
                +{Math.floor((comboMultiplier - 1) * 100)}% Bonus
              </span>
            </div>
            <Progress 
              value={(state.combo / 10) * 100} 
              className="h-2"
            />
          </Card>
        )}

        {/* Current Guess Display */}
        <Card className="glass p-8">
          <div className="min-h-[80px] flex items-center justify-center">
            {currentWord ? (
              <p className="text-5xl font-bold text-primary text-glow tracking-wider animate-bounce-in">
                {currentWord}
              </p>
            ) : (
              <p className="text-2xl text-muted-foreground">
                Tap letters to form words
              </p>
            )}
          </div>
        </Card>

        {/* Letter Tiles */}
        <div className="grid grid-cols-5 gap-3 md:gap-4">
          {state.letters.map((letter, index) => {
            const isUsed = usedIndices.has(index);
            return (
              <button
                key={`${letter}-${index}-${state.letters.join('')}`}
                onClick={() => !isUsed && selectLetter(letter, index)}
                disabled={isUsed}
                className={`
                  letter-tile aspect-square rounded-xl text-4xl md:text-5xl font-bold
                  border-2 transition-all duration-200
                  ${styleClass}
                  ${isUsed ? 'used opacity-30 scale-90' : 'hover:scale-105 active:scale-95'}
                  ${!isUsed ? 'box-glow' : ''}
                `}
              >
                {letter}
              </button>
            );
          })}
        </div>

        {/* Power-Ups */}
        <PowerUpsPanel />

        {/* Keyboard Hints */}
        <div className="text-center text-xs text-muted-foreground">
          <kbd className="px-2 py-1 rounded bg-muted/20 border border-muted">Enter</kbd> to submit •{' '}
          <kbd className="px-2 py-1 rounded bg-muted/20 border border-muted">Esc</kbd> to clear
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button
            size="lg"
            variant="outline"
            onClick={clearGuess}
            disabled={currentWord.length === 0}
            className="glass h-16 text-lg"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            Clear
          </Button>
          <Button
            size="lg"
            onClick={submitWord}
            disabled={currentWord.length < 2}
            className="h-16 text-lg bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-transform box-glow"
          >
            <Send className="w-5 h-5 mr-2" />
            Submit
          </Button>
        </div>

        {/* Found Words */}
        <Card className="glass p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Found Words</h3>
            <span className="text-lg text-primary font-bold">
              {state.foundWords.size} / {state.allPossibleWords.size}
            </span>
          </div>
          
          <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto">
            {Array.from(state.foundWords).sort((a, b) => b.length - a.length).map((word, index) => (
              <div
                key={word}
                className="animate-bounce-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <WordDefinition word={word} className="text-sm font-medium" />
              </div>
            ))}
          </div>
          
          {state.foundWords.size === 0 && (
            <p className="text-center text-muted-foreground py-8">
              No words found yet. Start playing!
            </p>
          )}
        </Card>
      </div>
    </div>
  );
}
